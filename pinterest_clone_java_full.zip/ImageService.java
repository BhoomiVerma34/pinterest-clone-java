// ImageService.java
public class ImageService { public String validateImageUrl(String url) { if(url==null || url.isEmpty()) return "default.jpg"; return url; } }