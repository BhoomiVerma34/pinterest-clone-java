// Server.java
public class Server { private Router router; public Server() { this.router = new Router(); } public void start() { System.out.println("Server is running..."); router.setupRoutes(); } }