// Main.java
public class Main { public static void main(String[] args) { System.out.println("Starting Pinterest Clone Server..."); Server server = new Server(); server.start(); } }